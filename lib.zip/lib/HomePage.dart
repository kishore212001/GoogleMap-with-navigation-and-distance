import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:gmap/location_services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
//import 'package:gmap/services.dart';

class MapSample extends StatefulWidget {
  const MapSample({super.key});

  @override
  State<MapSample> createState() => MapSampleState();
}

class MapSampleState extends State<MapSample> {
// class MapSample with ChangeNotifier{


 final Completer<GoogleMapController> _controller =
  Completer<GoogleMapController>();
//---------------------TEXTEDITING CONTROLLER------------------------//

  TextEditingController _orginController = TextEditingController();
  TextEditingController _destinationController = TextEditingController();
//-------------------------GOOGLEPLEX---------------------------------//
  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );
  //--------------------------------------------------------------------//
  Set<Marker>_markers = Set<Marker>();
  Set<Polygon>_polygons = Set<Polygon>();
  Set<Polyline>_polylines = Set<Polyline>();
  List<LatLng> polygonLatLngs  = <LatLng>[];
  List<PointLatLng> myList = [];

  int _polygonIdCounter = 1;
  int _polylineIdCounter = 1;
  //------------------------MARKER----------------------------//
  @override
  void initState(){
    super.initState();
    _setMarker(LatLng(37.42796133580664, -122.085749655962));
  }
  void _setMarker(LatLng point){
    setState(() {
      _markers.add(
        Marker(markerId: MarkerId('marker'), position: point),);
    });
  }
  //------------------------POLYGON----------------------------//
  void _setPolygon(){
    final String polygonIdval = 'polygon_$_polygonIdCounter';
    _polygonIdCounter++;
    _polygons.add(
      Polygon(polygonId: PolygonId(polygonIdval),
      points:polygonLatLngs,
        strokeWidth: 2,
        fillColor: Colors.transparent,
      ),);
  }
  //------------------------POLYLINE----------------------------//
  void _setPolyline(List<PointLatLng>points){
    final String polylineIdval = 'polyline_$_polylineIdCounter';
    _polylineIdCounter++;
    _polylines.add(
      Polyline(polylineId: PolylineId(polylineIdval),
        width: 2,
        color: Colors.blue,
        points: points.map(
            (point)=>LatLng(point.latitude, point.longitude),
        )
          .toList(),
      ),

    );

  }
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(title: Text("  Google Map  "),),
      body:
          Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      children: [
          TextFormField(
          controller: _orginController,
            textCapitalization: TextCapitalization.words,
            decoration: InputDecoration(hintText: 'Orgin'),
            onChanged: (value){
                    print(value);
            },

          ),
        TextFormField(
          controller: _destinationController,
          textCapitalization: TextCapitalization.words,
          decoration: InputDecoration(hintText: 'Destination'),
          onChanged: (value){
            print(value);
          },
        ),
                      ],
                    ),
                  ),
                  IconButton(onPressed: () async {
                   var directions = await LocationService().getDirection(
                       _orginController.text,
                       _destinationController.text);
                    _goToPlace(
                        directions['start_location']['lat'],directions['start_location']['lng'],
                        directions['bounds_ne'],directions['bounds_sw'],
                    );
                    _setPolyline(directions['polyline.decode']);
                  }, icon: Icon(Icons.search)),
                ],
              ),
               Expanded(
                 child: GoogleMap(
                mapType: MapType.normal,
                initialCameraPosition: _kGooglePlex,
                markers: _markers,
                polygons: _polygons,
                polylines: _polylines,
                onMapCreated: (GoogleMapController controller) {
                  _controller.complete(controller);
                },
                onTap: (points) {
                  setState(() {
                    polygonLatLngs.add(points);
                    _setPolygon();
                  });
                },
              ),
            ),
           ],
        ),
      );

  }
  Future<void> _goToPlace(
      double lat,
      double lng,
      Map<String,dynamic> boundsNe,
      Map<String, dynamic> boundsSw,
      )
      //(Map<String, dynamic>place)
  async {
   // final double lat = place ['geometry']['location']['lat'];
    //final double lng = place ['geometry']['location']['lng'];

    final GoogleMapController controller = await _controller.future;
    await controller.animateCamera(CameraUpdate.newCameraPosition(
      CameraPosition(target: LatLng(lat,lng),zoom: 12)
    ));
   controller.animateCamera(
        CameraUpdate.newLatLngBounds(
              LatLngBounds(
                    southwest: LatLng(boundsSw['lat'],boundsSw['lng']),
                    northeast:LatLng(boundsNe['lat'],boundsNe['lng'])), 25));


    _setMarker(LatLng(lat, lng));
  }

}